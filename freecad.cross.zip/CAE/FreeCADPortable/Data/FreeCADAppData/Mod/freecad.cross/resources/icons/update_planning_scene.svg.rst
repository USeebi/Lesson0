========================================
Logo for the UpdatePlanningScene command
========================================

The double-arrow symbol is from `view-refresh.svg` of FreeCAD.

