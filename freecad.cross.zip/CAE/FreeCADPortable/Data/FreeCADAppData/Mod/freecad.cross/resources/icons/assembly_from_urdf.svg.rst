The "Model" icon is taken from the `Assembly4 workbench<https://github.com/Zolko-123/FreeCAD_Assembly4>`_.
