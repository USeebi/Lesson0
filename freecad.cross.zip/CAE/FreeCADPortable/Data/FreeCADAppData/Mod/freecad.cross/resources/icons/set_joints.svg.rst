The robotic-arm symbol was originally designed by Inkie30 and obtained from `OpenClipard<https://openclipart.org/detail/232968/robotic-arm>`_.
